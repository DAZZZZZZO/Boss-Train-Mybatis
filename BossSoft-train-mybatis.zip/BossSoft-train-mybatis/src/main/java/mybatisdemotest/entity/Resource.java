package mybatisdemotest.entity;

/**
 * @version 1.0
 * @class: Resource
 * @Description:
 * @Author: Dazo
 * @date: 5/5/2023
 */
public class Resource {
    private Long id;
    private String name;
}
