package mybatisdemotest.utils;

import mybatisdemotest.dao.mapper.UserMapper;
import mybatisdemotest.entity.User;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

/**
 * @version 1.0
 * @class: MyBatisResultMapDemoTest
 * @Description:
 * @Author: Dazo
 * @date: 5/5/2023
 */
public class MyBatisResultMapDemoTest {
    @Autowired
    private UserMapper userMapper;

    @Test
    public void test1() {
        User user = userMapper.selectUserById(1L);
        // 断言user.roles的数量
        Assert.assertEquals(2, user.getRoles().size());

        // 断言user.roles中Resource数量总和
        int total = user.getRoles().stream().mapToInt(r -> r.getResources().size()).sum();
        Assert.assertEquals(3, total);
    }
}
