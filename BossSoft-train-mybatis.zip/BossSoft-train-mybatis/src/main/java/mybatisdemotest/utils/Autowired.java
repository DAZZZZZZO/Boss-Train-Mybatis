package mybatisdemotest.utils;

/**
 * @version 1.0
 * @class: Autowired
 * @Description:
 * @Author: Dazo
 * @date: 5/5/2023
 */
public @interface Autowired {
}
