package mybatisdemotest.dao.mapper;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @version 1.0
 * @class: UserMapperTest
 * @Description:
 * @Author: Dazo
 * @date: 5/5/2023
 */
class UserMapperTest {

    @Test
    void selectUserById() {
    }

    @Test
    void selectByExample() {
    }
}